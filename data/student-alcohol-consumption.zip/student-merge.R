setwd("D:/2018.07 R_DataAnalysis/2018SUMMER_R/data")

stud <- read.csv("student-por.csv")
stud$alc <- stud$Dalc + stud$Walc
stud.ex <- subset(stud, select = c("studytime", "alc"))
summary(stud.ex)
cor(stud.ex)
ggplot(data=stud.ex)